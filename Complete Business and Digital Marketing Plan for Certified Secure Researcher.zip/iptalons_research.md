# IPTalons Research Findings

## Homepage Information

### Core Mission & Philosophy
- **Tagline**: "Safeguard Innovation. Protect What Matters Most."
- **Core Philosophy**: "The research environment should be as open as possible, but as secure as necessary."
- **Focus**: Risk management services that protect intellectual property while prioritizing organizational values

### Value Proposition
- Helps world-class organizations maintain culture of innovation and collaboration
- Enables organizations to meet risk landscape challenges without sacrificing innovative values
- Combines technology, policy, and human behavior insights

### Key Metrics (Client Results)
- **100%** Client Satisfaction
- **$44M** Research Dollars Saved
- **4000+** Insider Risks Remediated
- **20** Critical Technology Categories Protected

### Target Industries (from client testimonials)
1. Healthcare
2. Aerospace
3. Pharmaceutical
4. Fortune 100 Companies

### Client Pain Points Addressed
- Trade secret protection
- Data loss prevention
- Employee behavioral analysis
- Insider threat risk mitigation
- Research security concerns
- Cybersecurity program supplementation

### Products/Services Mentioned
- **RedBook** - flagship product for reducing research security concerns (mentioned in banner)
- Risk Management Services
- Trade Secret Protection Programs
- Research security program design
- Hands-on project management

## Next Steps
- Explore Services page
- Explore Education page
- Explore Who We Are page
- Explore Use Cases page
- Explore Insights page


## Services Page - Detailed Product/Service Offerings

### 1. RedBook - Foreign Influence Risk Detection Portal
**Purpose**: Identify foreign influence risks related to undisclosed foreign research collaborations and funding sources

**Key Features**:
- Cloud-based platform for instant actionable insights
- Cost-effective one-stop shop for processing and identifying risks
- Saves time and resources compared to multiple expensive databases
- Addresses federal research grant funding authority enforcement actions
- Prevents financial penalties and reputational damage

**Target Pain Points**:
- Time-consuming and labor-intensive manual processes
- Need for multiple expensive databases
- Large analyst teams
- Intrusive approaches that alienate researchers, PIs, faculty, and students
- Minimal results from traditional approaches

### 2. RedBook+ - Enhanced Risk Resolution Service
**Purpose**: Annual subscription providing tools and services to resolve risk and comply with federal/state research security regulations

**Subscription Includes**:
- Customized RedBook dashport for visualizing research security and compliance risks
- Online research security program assessment tool
- Express COI Veracity Checks (verify accuracy of foreign collaboration/funding disclosures)
- Comprehensive policy framework review and gap analysis
- Step-by-step research security program implementation guide and roadmap
- Deep-dive reporting for research security incident management
- Access to IPTalons SMEs and Analysts for advice, coaching, support

### 3. Grant Hopper - Research Scholar & Grant Application Security Analyzer
**Purpose**: World's first AI-enabled due diligence tool for assessing visiting scholars, researchers, and grant applicants

**Key Features**:
- Identifies and mitigates foreign influence risks
- Efficient assessment of visiting scholars, prospective researchers, grant applicants
- Built for academic institutions, government agencies, corporate R&D teams
- Protects against economic espionage, IP theft, reputational damage

**Threats Addressed**:
- Foreign influence in unexpected places
- Economic espionage
- Intellectual property theft
- Reputational damage

### 4. Innovation Defense Academy
**Purpose**: Training designed to promote effective security culture

**Key Statistics**:
- 95% of insider IP loss and theft is unintentional
- Most employees unaware of internal/external threats

**Pricing**: $10 per learner monthly (enterprise pricing available)

**Features**:
- Micro-course library
- Best research security practices for employees at every level
- Protection from espionage, competitive theft, accidental public disclosures
- Training for employees, contractors, supply chain partners

**Target Audience**:
- Employees with access to research, trade secrets, proprietary information
- Team members with access to "crown jewels"

### 5. Research Security Officer Certificate Training
**Purpose**: Professional certificate for research security expertise

**Target Audience**:
- Research security officers
- Facility security officers
- Research administrators
- Export control specialists
- Contracts administrators
- Research program managers

**Provider**: Research Security Management Institute

**Focus**: Fundamental areas of expertise needed for Research Security Officer roles

### 6. Innovation Defender™
**Purpose**: Affordable solution for managing insider and outsider risks

**Target Audience**:
- Critical technology sector companies
- University startups
- Early-stage companies
- Supply chain partners
- Cutting-edge technology R&D organizations without internal expertise

**Services Provided**:
- Solid compliance policy framework creation
- Employee and contractor education
- Executive-level security advice
- Risk assessment
- Remediation strategy development


## Who We Are - Company Background & Team

### Company Mission Statement
"Protecting Your Life's Work is Our Life's Work."

### Company Philosophy
- Understands research is product of years of time, effort, and sacrifice
- Commitment and dedication to safeguarding innovations
- Risk management service provider matching client commitment

### Leadership Team

#### Allen Phelps - Founder & CEO
**Background**:
- Board-certified security professional
- Focused on Research Security Management Programs and Insider Threat Management Programs
- Former CIA (nearly two decades in various roles)
- Established trade secret protection program at Merck & Co. (cited as best-in-class)
- Former research security training role at Texas A&M University System

**Expertise**: Safeguarding IP, research, trade secrets, proprietary information from loss, theft, misappropriation

#### Stefano Serafini - Chief Revenue Officer & VP International
**Background**:
- 25 years US Government Executive Branch service
- National and international security and risk analysis expert
- Tours in Near East, South Asia, North Africa, Europe
- Extensive engagement with US Intelligence Community and US Military
- Joint Terrorism Task Force experience post-9/11
- Own consulting firm (2020+): market intelligence, risk management, business development

**Education**: 
- Masters in National Security Studies (minor in Cybersecurity Strategy) - National Defense University's Eisenhower School
- BS in Exercise Physiology - USC

#### Carl Taylor - VP Academic Engagement
**Background**:
- 30 years US service (Military Intelligence Officer + DoD Special Agent/Intelligence Officer)
- Counterintelligence, counterterrorism, counterproliferation focus
- Retired as Assistant Director of US Defense Agency (2015)
- Former Chief Security Officer - University of Kansas
- Developed Office of Global Operations & Security (GOS)
- Co-Principal Investigator for KU's Intelligence Community Center for Academic Excellence
- Executive Board - Association of University Research Security Professionals

**Education**:
- BS Management Science - Bridgewater State University
- Senior Executive Fellow Program - Kennedy School of Government, Harvard

#### Jeff Hinson - CFO & Board Member
**Background**:
- Former CFO of two NYSE-traded companies (Univision Communications, Hispanic Broadcasting)
- 17 years public company board experience (up to 4 boards simultaneously)
- Board Chairman, Audit Committee Chair, Governance Chair roles
- National Association of Corporate Directors member
- Experience: compliance, enterprise risk, security risk, IP licensing
- Mentor at Capital Factory
- Board member of venture-backed startups

**Education**: BBA and MBA - University of Texas at Austin

#### Stan Woodward - Business Development, Board Member
**Background**:
- Former CEO & Chairman of MVPindex, Inc.
- Co-founder of MyLifeIQ (genomics health/wellness - sold to Recuro Health)
- Co-founder Quantum Symphony Group (cybersecurity consulting)
- Former CEO of LTF, Inc. (now National Math and Science Initiative)
- Seasoned entrepreneur in tech startups (Yahoo!, broadcast.com, Ascend)
- Invested in 70+ early-stage ventures since 1995
- Participated in successful IPOs ($30B+ combined market valuation)
- Senior trustee for Austin College

**Education**: B.S.E.E. - Oklahoma State University

#### Bill Davis - Board Member
**Background**:
- Chairman & CEO of Dexter & Company (second-oldest business in Dallas)
- Property, casualty, benefits insurance brokerage
- First Lieutenant - US Army
- Individual Ready Reserve
- Board Member - Ronald McDonald House of Dallas
- Member: Young President's Organization, Chief Executive Round Table

**Education**: BBA Finance - Texas Christian University

### Team Expertise Summary
- Intelligence community (CIA, DoD, Military Intelligence)
- Academic research security
- Corporate security (Fortune 100, pharmaceutical, aerospace)
- Cybersecurity and risk management
- Financial management and compliance
- Business development and entrepreneurship
- Government relations and policy


## Use Cases - Target Market Segments

### 1. Research Parks, Innovation Hubs, + Incubators
**Services Provided**:
- Managed research security services for start-up community
- Outsourced research security for early-stage projects
- Due diligence and vetting of potential tenants
- Foreign influence threat detection before infiltration

**Benefits**:
- Protects from foreign influence and unethical competitors
- Reduces internal administrative burdens
- Positions technologies for fundraising, commercialization, licensing, acquisition

### 2. Small and Midsize Businesses (SMBs)
**Services Provided**:
- Proactive risk management services
- Outsourced, cost-effective innovation defense solutions
- Complete subscription-based package (Innovation Defender™)

**Package Includes**:
- Policy framework
- Employee training
- Leadership consulting
- Risk assessment advisory services

**Target**: Pre-revenue through midsized companies

**Benefits**:
- World-class security program
- Demonstrates commitment to protecting IP
- Assurances to investors, employees, supply chain partners, customers

### 3. Investment Due Diligence
**Target Clients**: Venture Capital (VC), Private Equity (PE), Family Offices

**Services Provided**:
- Evaluate risk of IP misuse, loss, theft, misappropriation
- Risk element for investment decision process
- Assessment of company's ability to protect innovations, trade secrets, team members, IP
- Managed services to protect investments (gap filling)

**Threats Assessed**:
- Insiders and outsiders
- Foreign influence threat actors
- Unethical competitors

### 4. Research Universities + Institutions
**Target**: Leading universities and research institutions (US and worldwide)

**Services Provided**:
- Managed research security services
- "Easy button" for research security compliance
- Program design, implementation, management, continuous improvement
- Right-sized, cost-effective programs

**Compliance Requirements Addressed**:
- NSPM-33
- CHIPS and Sciences Act
- NDAA
- DoD CUI
- SBIR/STTR
- NIH, DoE, NASA, NOAA
- Corporate-sponsored grants and contracts

**Risk Areas Managed**:
- Foreign influence
- Foreign travel
- Cybersecurity
- Export control
- Conflicts of interest and commitment

### 5. Critical Technology Companies
**Target**: Large companies and research enterprises in critical technology sectors

**Services Provided**:
- Assess and improve insider risk management programs
- Strategic risk management plans
- Merger and acquisition due diligence checks
- High-risk employee terminations
- External partner vetting activities
- Supply chain security assessments
- User behavior monitoring
- Insider threat investigations

**Critical Technology Sectors** (18 categories):
1. Advanced Computing
2. Advanced Engineering Materials
3. Advanced Gas Turbine Engine Technologies
4. Advanced and Networked Sensing and Signature Management
5. Advanced Manufacturing
6. Artificial Intelligence
7. Biotechnologies
8. Clean Energy Generation and Storage
9. Data Privacy, Data Security, and Cybersecurity Technologies
10. Directed Energy
11. Highly Automated, Autonomous, and Uncrewed Systems and Robotics
12. Human-Machine Interfaces
13. Hypersonics
14. Integrated Communication and Networking Technologies
15. Positioning, Navigation, and Timing Technologies
16. Quantum Information and Enabling Technologies
17. Semiconductors and Microelectronics
18. Space Technologies and Systems


## Education - Training & Certification Programs

### Core Philosophy
"Innovation Protection Starts with People."

### Key Statistic
**95% of insider IP loss and theft is unintentional**

### Training Offerings

#### 1. Innovation Defense Academy
**Description**: Micro-course library designed to promote best research security practices

**Target Audience**: 
- Employees at every level
- Contractors
- Supply chain partners

**Pricing**: 
- $10 per learner monthly (annual subscription agreement)
- Special enterprise-level pricing available

**Purpose**:
- Protect against foreign influence, nation-state-sponsored, and commercial competitive threat actors
- Prevent espionage, competitive theft, accidental public disclosures
- Promote effective security culture

**Key Feature**: Meet NSPM-33 Training Requirements in 30 minutes (alternative to time-consuming resources)

#### 2. Research Security Management Certificates
**Provider**: Research Security Management Institute

**Target Audience**:
- Research security officers
- Facility security officers
- Research administrators
- Export control specialists
- Contracts administrators
- Research program managers

**Purpose**: Become expert on research security and compliance

#### 3. Custom Training and Awareness Programs
**Target**: Organizations of all sizes

**Services**:
- Branded courses and awareness campaigns
- Custom online courses
- Instructor-led workshops
- Webinar sessions

**Purpose**:
- Train employees, contractors, supply chain partners
- Protect intellectual property and proprietary data
- Reinforce compliance policies
- Promote culture of trust


## Certificate Courses - Detailed Information

### Research Security Management Certificate Program

**Five-Course Series** (Certificate of completion for each course):

1. **Research Security Fundamentals**
2. **Understanding Insider Threats**
3. **Elicitation**
4. **Travel Security**
5. **Best Practices in Research Security Management**

**Target Audience**:
- Research security officers
- Facility security officers
- Research administrators
- Export control specialists
- Contracts administrators
- Research program managers

**Purpose**: Train individuals on fundamental areas of expertise needed for Research Security Officer roles
